﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace demoekz
{
    public partial class technichian_control_panel : Form
    {
        public technichian_control_panel()
        {
            InitializeComponent();
        }

        private void button_tech_requests_Click(object sender, EventArgs e)
        {
            tech_all_requests frm_tech_ctrl_pnl = new tech_all_requests();
            Hide();
            frm_tech_ctrl_pnl.ShowDialog();
            Close();
        }

        private void button_tech_order_spares_Click(object sender, EventArgs e)
        {
            tech_choose_request_to_edit frm_tech_ctrl_pnl = new tech_choose_request_to_edit();
            Hide();
            frm_tech_ctrl_pnl.ShowDialog();
            Close();

        }

        private void button_tech_toManager_Click(object sender, EventArgs e)
        {
            client_managers frm_tech_ctrl_pnl = new client_managers();
            Hide();
            frm_tech_ctrl_pnl.ShowDialog();
            Close();
        }
    }
}
